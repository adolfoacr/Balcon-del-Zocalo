import Foundation

enum Verification: String, Codable {
    case demo, pending, verified
}

struct NewsItem: Identifiable, Codable {
    let id: String
    let title: String
    let date: String?
    let excerpt: String
    let body: String
    let iconName: String
    let kind: String
    let verification: Verification
    let source: String
    let sourceURL: String?
}

struct Recipe: Identifiable, Codable {
    let id: String
    let name: String
    let category: String
    let complexity: String?
    let ingredients: [String]
    let description: String
    let steps: [String]
    let servings: Int?
    let priceMXN: Double?
    let verification: Verification
    let source: String
    let sourceURL: String?
    let art: String

    func matches(_ query: String) -> Bool {
        query.isEmpty || ([name] + ingredients).joined(separator: " ")
            .range(of: query, options: [.caseInsensitive, .diacriticInsensitive]) != nil
    }
}

struct BookChapter: Identifiable, Codable {
    let id: String
    let chapterNumber: Int
    let title: String
    let summary: String
    let pagesCount: Int
    let source: String
    let verification: Verification
}

struct BookContent: Codable {
    let title: String
    let status: String
    let chapters: [BookChapter]
}

struct ContentCatalog: Codable {
    let schemaVersion: Int
    let restaurantName: String
    let news: [NewsItem]
    let recipes: [Recipe]
    let book: BookContent

    static func load(from bundle: Bundle) throws -> ContentCatalog {
        guard let url = bundle.url(forResource: "content", withExtension: "json") else {
            throw ContentError.missingFile
        }
        let content = try JSONDecoder().decode(ContentCatalog.self, from: Data(contentsOf: url))
        let ids = content.news.map(\.id) + content.recipes.map(\.id) + content.book.chapters.map(\.id)
        guard content.schemaVersion == 1, ids.allSatisfy({ !$0.isEmpty }), Set(ids).count == ids.count else {
            throw ContentError.invalidData
        }
        return content
    }

    #if SWIFT_PACKAGE
    static func bundled() throws -> ContentCatalog { try load(from: .module) }
    #endif
}

enum ContentError: Error {
    case missingFile, invalidData
}
