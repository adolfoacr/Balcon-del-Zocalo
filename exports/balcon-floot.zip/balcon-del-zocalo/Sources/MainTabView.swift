import SwiftUI

enum AppTab: Hashable { case news, recipes, book }

struct MainTabView: View {
    @EnvironmentObject private var content: ContentStore
    @State private var selectedTab: AppTab = .news

    var body: some View {
        if content.catalog != nil {
            TabView(selection: $selectedTab) {
                NewsView(selectedTab: $selectedTab)
                    .tabItem { Label("Noticias", systemImage: "newspaper") }.tag(AppTab.news)
                RecipeBookView()
                    .tabItem { Label("Recetario", systemImage: "fork.knife") }.tag(AppTab.recipes)
                PublishedBookView()
                    .tabItem { Label("Nuestro libro", systemImage: "book.closed") }.tag(AppTab.book)
            }
        } else {
            ContentUnavailableView {
                Label("No pudimos cargar el contenido", systemImage: "exclamationmark.circle")
            } description: {
                Text("Vuelve a intentarlo. Tus favoritos y tu libro se conservan en el dispositivo.")
            } actions: {
                Button("Intentar de nuevo") { content.reload() }.buttonStyle(.borderedProminent)
            }
        }
    }
}
