import SwiftUI

enum PilotTheme {
    static let green = Color(red: 0.10, green: 0.24, blue: 0.21)
    static let gold = Color(red: 0.60, green: 0.42, blue: 0.15)
    static let paper = Color(uiColor: .systemGroupedBackground)
}

struct SectionIntro: View {
    let eyebrow: String
    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(eyebrow.uppercased()).font(.caption.weight(.semibold)).foregroundStyle(PilotTheme.gold)
            Text(title).font(.system(.largeTitle, design: .serif)).fixedSize(horizontal: false, vertical: true)
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct ContentNotice: View {
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "info.circle").foregroundStyle(PilotTheme.gold)
            Text(text).font(.footnote).foregroundStyle(.secondary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(PilotTheme.gold.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
    }
}

struct SourceNote: View {
    let source: String
    let url: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Divider()
            Text("Sobre este contenido").font(.footnote.weight(.semibold))
            Text(source).font(.footnote).foregroundStyle(.secondary)
            if let url, let destination = URL(string: url), destination.scheme == "https" {
                Link("Consultar fuente", destination: destination).font(.footnote)
            }
        }
    }
}

struct PilotCard: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
    }
}

extension View {
    func pilotCard() -> some View { modifier(PilotCard()) }
}
