import SwiftUI

struct NewsView: View {
    @EnvironmentObject private var content: ContentStore
    @Binding var selectedTab: AppTab

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 18) {
                        Text("EXPERIENCIA GASTRONÓMICA").font(.caption.weight(.semibold))
                            .foregroundStyle(Color(red: 0.85, green: 0.73, blue: 0.51))
                        Text("Una mesa.\nMuchas historias.").font(.system(.largeTitle, design: .serif))
                        Text("Explora sabores, encuentra tus favoritos y descubre el espacio de nuestro libro.")
                            .font(.subheadline).foregroundStyle(.white.opacity(0.85))
                        Button { selectedTab = .recipes } label: {
                            Label("Explorar el recetario", systemImage: "arrow.up.right")
                                .font(.subheadline.weight(.semibold)).padding(.vertical, 6)
                        }
                        .buttonStyle(.borderedProminent).tint(.white).foregroundStyle(PilotTheme.green)
                    }
                    .padding(26).frame(maxWidth: .infinity, alignment: .leading)
                    .background(PilotTheme.green, in: RoundedRectangle(cornerRadius: 20))
                    .foregroundStyle(.white)
                    Text("Para descubrir").font(.system(.title2, design: .serif))
                    ContentNotice(text: "Estas tarjetas presentan la muestra. Las noticias oficiales se incorporarán después de verificarlas.")
                    ForEach(content.catalog?.news ?? []) { item in
                        NavigationLink {
                            NewsDetailView(item: item)
                        } label: {
                            VStack(alignment: .leading, spacing: 14) {
                                HStack {
                                    Image(systemName: item.iconName).font(.title2).foregroundStyle(PilotTheme.gold)
                                    Spacer()
                                    Text(item.kind).font(.caption).foregroundStyle(.secondary)
                                }
                                Text(item.title).font(.system(.title3, design: .serif))
                                Text(item.excerpt).font(.subheadline).foregroundStyle(.secondary)
                                Label("Leer más", systemImage: "arrow.right").font(.footnote.weight(.semibold))
                                    .foregroundStyle(PilotTheme.gold)
                            }.pilotCard()
                        }.buttonStyle(.plain)
                    }
                }.padding(20)
            }
            .background(PilotTheme.paper)
            .navigationTitle("Balcón del Zócalo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Text("Piloto").font(.caption).foregroundStyle(.secondary) } }
        }
    }
}

struct NewsDetailView: View {
    let item: NewsItem

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                SectionIntro(eyebrow: item.kind, title: item.title, subtitle: item.excerpt)
                if let date = item.date { Text(date).font(.caption).foregroundStyle(.secondary) }
                Text(item.body).lineSpacing(5)
                SourceNote(source: item.source, url: item.sourceURL)
            }.padding(24)
        }.navigationTitle("Noticias").navigationBarTitleDisplayMode(.inline)
    }
}
