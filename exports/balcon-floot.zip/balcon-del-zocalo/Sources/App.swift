import SwiftUI

@main
struct BalconZocaloApp: App {
    @StateObject private var content = ContentStore()
    @StateObject private var library = BookStore()

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(content)
                .environmentObject(library)
                .tint(PilotTheme.green)
                .preferredColorScheme(.light)
        }
    }
}
