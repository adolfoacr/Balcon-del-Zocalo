import SwiftUI

struct RecipeBookView: View {
    @EnvironmentObject private var content: ContentStore
    @State private var query = ""
    @State private var category = "Todos"

    private var categories: [String] {
        ["Todos"] + Array(Set((content.catalog?.recipes ?? []).map(\.category))).sorted() + ["Favoritos"]
    }
    private var filtered: [Recipe] {
        (content.catalog?.recipes ?? []).filter {
            $0.matches(query) && (category == "Todos" || (category == "Favoritos" ? content.favorites.contains($0.id) : $0.category == category))
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    SectionIntro(eyebrow: "Recetario de autor", title: "Sabores por descubrir.",
                                 subtitle: "Conoce los ingredientes de cada plato y guarda lo que más te inspire.")
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(categories, id: \.self) { option in
                                Button(option) { category = option }
                                    .font(.subheadline).padding(.horizontal, 16).frame(minHeight: 44)
                                    .background(category == option ? PilotTheme.green : Color(uiColor: .secondarySystemGroupedBackground), in: Capsule())
                                    .foregroundStyle(category == option ? Color.white : Color.primary)
                                    .accessibilityAddTraits(category == option ? .isSelected : [])
                            }
                        }
                    }
                    ContentNotice(text: "Contenido gastronómico de muestra. Los ingredientes y la preparación completa se confirmarán con el restaurante.")
                    Text("\(filtered.count) \(filtered.count == 1 ? "plato" : "platos")").font(.footnote).foregroundStyle(.secondary)
                    if filtered.isEmpty {
                        ContentUnavailableView {
                            Label(category == "Favoritos" ? "Aquí estarán tus favoritos" : "No encontramos ese sabor",
                                  systemImage: category == "Favoritos" ? "heart" : "magnifyingglass")
                        } description: {
                            Text(category == "Favoritos" ? "Toca el corazón de un plato para guardarlo." : "Prueba con otro nombre o ingrediente.")
                        } actions: {
                            Button("Ver todos los platos") { query = ""; category = "Todos" }.buttonStyle(.bordered)
                        }
                    }
                    ForEach(filtered) { recipe in
                        VStack(alignment: .leading, spacing: 16) {
                            HStack {
                                Label(recipe.category, systemImage: "fork.knife").font(.caption).foregroundStyle(PilotTheme.gold)
                                Spacer()
                                favoriteButton(recipe)
                            }
                            Text(recipe.name).font(.system(.title2, design: .serif))
                            Text(recipe.description).font(.subheadline).foregroundStyle(.secondary)
                            NavigationLink { RecipeDetailView(recipe: recipe) } label: {
                                Label("Ver ingredientes", systemImage: "arrow.right").frame(maxWidth: .infinity).padding(.vertical, 7)
                            }.buttonStyle(.bordered)
                        }.pilotCard()
                    }
                }.padding(20)
            }
            .background(PilotTheme.paper)
            .navigationTitle("Recetario")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "Plato o ingrediente")
        }
    }

    private func favoriteButton(_ recipe: Recipe) -> some View {
        Button { content.toggleFavorite(recipe.id) } label: {
            Image(systemName: content.favorites.contains(recipe.id) ? "heart.fill" : "heart")
                .font(.title3).frame(minWidth: 44, minHeight: 44)
        }
        .accessibilityLabel("\(content.favorites.contains(recipe.id) ? "Quitar de favoritos" : "Guardar en favoritos"): \(recipe.name)")
        .accessibilityValue(content.favorites.contains(recipe.id) ? "Guardado" : "Sin guardar")
    }
}

struct RecipeDetailView: View {
    @EnvironmentObject private var content: ContentStore
    let recipe: Recipe

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                SectionIntro(eyebrow: "\(recipe.category) · Contenido de muestra", title: recipe.name, subtitle: recipe.description)
                Text("Ingredientes destacados").font(.system(.title2, design: .serif))
                VStack(alignment: .leading, spacing: 14) {
                    ForEach(recipe.ingredients, id: \.self) { ingredient in
                        Label(ingredient, systemImage: "leaf").font(.body)
                    }
                }
                if recipe.steps.isEmpty {
                    ContentNotice(text: "La receta completa se añadirá cuando el restaurante comparta cantidades y preparación. Esta ficha no es una guía para cocinar.")
                } else {
                    Text("Preparación").font(.system(.title2, design: .serif))
                    ForEach(Array(recipe.steps.enumerated()), id: \.offset) { index, step in
                        Text("\(index + 1). \(step)")
                    }
                }
                if let complexity = recipe.complexity { Text("Dificultad: \(complexity)").font(.subheadline) }
                if let servings = recipe.servings { Text("Porciones: \(servings)").font(.subheadline) }
                Button { content.toggleFavorite(recipe.id) } label: {
                    Label(content.favorites.contains(recipe.id) ? "Quitar de favoritos" : "Guardar en favoritos",
                          systemImage: content.favorites.contains(recipe.id) ? "heart.fill" : "heart")
                        .frame(maxWidth: .infinity).padding(.vertical, 7)
                }.buttonStyle(.borderedProminent)
                SourceNote(source: recipe.source, url: recipe.sourceURL)
            }.padding(24)
        }.navigationTitle("El plato").navigationBarTitleDisplayMode(.inline)
    }
}
