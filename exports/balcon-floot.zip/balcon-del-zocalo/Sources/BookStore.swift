import SwiftUI
import PDFKit

@MainActor
final class BookStore: ObservableObject {
    @Published private(set) var document: PDFDocument?
    @Published private(set) var filename = ""
    @Published var currentPage = 0
    @Published var errorMessage: String?
    private let fileURL: URL

    init() {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("BalconLibrary", isDirectory: true)
        fileURL = directory.appendingPathComponent("restaurant-book.pdf")
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: fileURL.path) {
                guard let saved = PDFDocument(url: fileURL), !saved.isLocked, saved.pageCount > 0 else {
                    throw BookImportError.invalidPDF
                }
                document = saved
                filename = UserDefaults.standard.string(forKey: "balcon-book-name") ?? "Nuestro libro.pdf"
            }
        } catch { errorMessage = "No pudimos recuperar el libro guardado. Puedes volver a cargarlo." }
    }

    func importPDF(from url: URL) {
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer { if hasAccess { url.stopAccessingSecurityScopedResource() } }
        do {
            let properties = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
            guard properties.isRegularFile == true,
                  let size = properties.fileSize, size > 0, size <= 30 * 1024 * 1024 else {
                throw BookImportError.tooLarge
            }
            let data = try Data(contentsOf: url, options: .mappedIfSafe)
            guard data.count <= 30 * 1024 * 1024,
                  String(decoding: data.prefix(1024), as: UTF8.self).contains("%PDF-"),
                  let candidate = PDFDocument(data: data) else { throw BookImportError.invalidPDF }
            guard !candidate.isLocked else { throw BookImportError.locked }
            guard candidate.pageCount > 0, candidate.pageCount <= 1000 else { throw BookImportError.invalidPDF }
            // Atomic writing preserves the previous imported book if saving fails.
            try data.write(to: fileURL, options: .atomic)
            document = candidate
            filename = url.lastPathComponent
            currentPage = 0
            UserDefaults.standard.set(filename, forKey: "balcon-book-name")
            errorMessage = nil
        } catch BookImportError.tooLarge {
            errorMessage = "Elige un PDF de hasta 30 MB."
        } catch BookImportError.locked {
            errorMessage = "Este PDF tiene contraseña. Usa una copia sin protección."
        } catch {
            errorMessage = "No pudimos abrir ese PDF. Usa un documento válido de hasta 1.000 páginas."
        }
    }

    func removeBook() {
        do {
            if FileManager.default.fileExists(atPath: fileURL.path) { try FileManager.default.removeItem(at: fileURL) }
            document = nil
            filename = ""
            currentPage = 0
            UserDefaults.standard.removeObject(forKey: "balcon-book-name")
            errorMessage = nil
        } catch { errorMessage = "No pudimos retirar la copia guardada. Intenta de nuevo." }
    }
}

private enum BookImportError: Error { case tooLarge, invalidPDF, locked }
