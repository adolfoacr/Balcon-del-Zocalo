import SwiftUI
import UniformTypeIdentifiers
import PDFKit

struct PublishedBookView: View {
    @EnvironmentObject private var library: BookStore
    @State private var importing = false
    @State private var confirmingRemoval = false

    var body: some View {
        NavigationStack {
            Group {
                if let document = library.document {
                    VStack(spacing: 12) {
                        Text(library.filename).font(.subheadline.weight(.medium)).lineLimit(2)
                            .padding(.horizontal, 20)
                        HStack {
                            Button { library.currentPage -= 1 } label: {
                                Image(systemName: "chevron.left").frame(minWidth: 44, minHeight: 44)
                            }.disabled(library.currentPage == 0).accessibilityLabel("Página anterior")
                            Spacer()
                            Text("Página \(library.currentPage + 1) de \(document.pageCount)").font(.subheadline)
                                .accessibilityAddTraits(.updatesFrequently)
                            Spacer()
                            Button { library.currentPage += 1 } label: {
                                Image(systemName: "chevron.right").frame(minWidth: 44, minHeight: 44)
                            }.disabled(library.currentPage + 1 >= document.pageCount).accessibilityLabel("Página siguiente")
                        }.padding(.horizontal, 16)
                        PDFReader(document: document, pageIndex: $library.currentPage)
                        Text("Tu PDF se guarda solo en este dispositivo.").font(.caption).foregroundStyle(.secondary)
                            .padding(.bottom, 12)
                    }
                } else {
                    emptyLibrary
                }
            }
            .background(PilotTheme.paper)
            .navigationTitle("Nuestro libro")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if library.document != nil {
                    ToolbarItem(placement: .topBarTrailing) {
                        Menu {
                            Button("Cambiar PDF", systemImage: "square.and.arrow.down") { importing = true }
                            Button("Retirar libro", systemImage: "trash", role: .destructive) { confirmingRemoval = true }
                        } label: { Image(systemName: "ellipsis.circle") }
                        .accessibilityLabel("Opciones del libro")
                    }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.pdf]) { result in
                switch result {
                case .success(let url): library.importPDF(from: url)
                case .failure(let error):
                    let cocoaError = error as NSError
                    if cocoaError.code != NSUserCancelledError {
                        library.errorMessage = "No pudimos acceder al archivo. Intenta seleccionarlo de nuevo."
                    }
                }
            }
            .confirmationDialog("¿Retirar este libro?", isPresented: $confirmingRemoval, titleVisibility: .visible) {
                Button("Retirar copia local", role: .destructive) { library.removeBook() }
                Button("Conservar libro", role: .cancel) { }
            } message: { Text("Tu archivo original seguirá intacto.") }
            .alert("No pudimos abrir el libro", isPresented: Binding(
                get: { library.errorMessage != nil },
                set: { if !$0 { library.errorMessage = nil } }
            )) { Button("Entendido") { library.errorMessage = nil } }
            message: { Text(library.errorMessage ?? "") }
        }
    }

    private var emptyLibrary: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                SectionIntro(eyebrow: "Nuestro libro", title: "Historias para saborear.", subtitle: "El siguiente capítulo lo compartes tú.")
                VStack(spacing: 16) {
                    Image(systemName: "book.closed").font(.system(size: 56)).foregroundStyle(PilotTheme.gold)
                    Text("Un lugar para cada página.").font(.system(.title2, design: .serif))
                    Text("Cuando compartas el libro, podrás recorrerlo aquí. Por ahora, prueba el lector con un PDF que tengas permiso de usar.")
                        .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    Button { importing = true } label: {
                        Label("Cargar un PDF", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity).padding(.vertical, 7)
                    }.buttonStyle(.borderedProminent)
                    Text("PDF de hasta 30 MB. Se guarda solo en este dispositivo.").font(.caption).foregroundStyle(.secondary)
                }.padding(24).frame(maxWidth: .infinity)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
                ContentNotice(text: "El libro, su índice y sus capítulos están pendientes de que el propietario comparta la información.")
            }.padding(20)
        }
    }
}

@MainActor
struct PDFReader: UIViewRepresentable {
    let document: PDFDocument
    @Binding var pageIndex: Int

    func makeUIView(context: Context) -> PDFView {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePage
        view.backgroundColor = UIColor.secondarySystemBackground
        view.document = document
        context.coordinator.observe(view)
        return view
    }

    func updateUIView(_ view: PDFView, context: Context) {
        context.coordinator.parent = self
        if view.document !== document { view.document = document }
        guard let target = document.page(at: pageIndex), view.currentPage !== target else { return }
        view.go(to: target)
    }

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    static func dismantleUIView(_ uiView: PDFView, coordinator: Coordinator) {
        NotificationCenter.default.removeObserver(coordinator)
    }

    @MainActor
    final class Coordinator: NSObject {
        var parent: PDFReader
        init(parent: PDFReader) { self.parent = parent }

        func observe(_ view: PDFView) {
            NotificationCenter.default.addObserver(self, selector: #selector(pageChanged(_:)),
                                                  name: .PDFViewPageChanged, object: view)
        }

        @objc private func pageChanged(_ notification: Notification) {
            guard let view = notification.object as? PDFView, let page = view.currentPage,
                  let document = view.document else { return }
            let index = document.index(for: page)
            guard index != NSNotFound, index != parent.pageIndex else { return }
            // PDFView emits notifications during updateUIView; defer the binding update.
            Task { @MainActor [weak self, weak document] in
                guard let self, let document, self.parent.document === document else { return }
                self.parent.pageIndex = index
            }
        }
    }
}
