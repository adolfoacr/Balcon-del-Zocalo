import XCTest
@testable import BalconContent

final class ContentTests: XCTestCase {
    func testBundledContentDecodesAndDoesNotInventTheBook() throws {
        let catalog = try ContentCatalog.bundled()
        XCTAssertEqual(catalog.restaurantName, "Balcón del Zócalo")
        XCTAssertEqual(catalog.recipes.count, 2)
        XCTAssertTrue(catalog.news.allSatisfy { $0.verification == .demo && $0.date == nil })
        XCTAssertTrue(catalog.book.chapters.isEmpty)
        XCTAssertEqual(catalog.book.status, "awaiting-owner")
    }

    func testSearchFindsIngredientsRegardlessOfAccents() throws {
        let catalog = try ContentCatalog.bundled()
        let sope = try XCTUnwrap(catalog.recipes.first { $0.id == "sope-totoaba" })
        XCTAssertTrue(sope.matches("MAIZ"))
        XCTAssertFalse(sope.matches("chocolate"))
    }

    func testIncompleteRecipesDoNotInventCookingInstructions() throws {
        for recipe in try ContentCatalog.bundled().recipes {
            XCTAssertTrue(recipe.steps.isEmpty)
            XCTAssertNil(recipe.complexity)
            XCTAssertNil(recipe.priceMXN)
            XCTAssertEqual(recipe.verification, .pending)
            XCTAssertFalse(recipe.source.isEmpty)
        }
    }
}
