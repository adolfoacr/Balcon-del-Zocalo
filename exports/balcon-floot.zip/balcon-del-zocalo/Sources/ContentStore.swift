import SwiftUI

@MainActor
final class ContentStore: ObservableObject {
    @Published private(set) var catalog: ContentCatalog?
    @Published private(set) var favorites: Set<String> = []
    @Published private(set) var loadingFailed = false
    private let favoritesKey = "balcon-favorites-v1"

    init() { reload() }

    func reload() {
        do {
            let loaded = try ContentCatalog.load(from: .main)
            catalog = loaded
            favorites = Set(UserDefaults.standard.stringArray(forKey: favoritesKey) ?? [])
                .intersection(Set(loaded.recipes.map(\.id)))
            loadingFailed = false
        } catch {
            catalog = nil
            loadingFailed = true
        }
    }

    func toggleFavorite(_ id: String) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
        UserDefaults.standard.set(Array(favorites), forKey: favoritesKey)
    }
}
