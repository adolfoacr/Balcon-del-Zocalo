// swift-tools-version: 6.0
import PackageDescription

// Shared models can be tested with SwiftPM. Build the iOS app using project.yml.
let package = Package(
    name: "BalconZocaloApp",
    platforms: [.iOS(.v17)],
    products: [.library(name: "BalconContent", targets: ["BalconContent"])],
    targets: [
        .target(name: "BalconContent", path: "Sources", sources: ["Models.swift"],
                resources: [.copy("Resources/content.json")]),
        .testTarget(name: "BalconContentTests", dependencies: ["BalconContent"], path: "Tests")
    ]
)
